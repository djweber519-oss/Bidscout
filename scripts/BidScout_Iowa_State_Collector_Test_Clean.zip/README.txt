BidScout Iowa public-listing test

1. Open your existing Bidscout repository on GitHub.
2. Open scripts/update_iowa.py and replace it with the new scripts/update_iowa.py.
3. Commit changes.
4. Go to Actions > Update Iowa contracts > Run workflow.
5. Expand the 'Update Iowa opportunities' log and read the output.

If the run is green and the log says 'Wrote ...', the public HTML listing was usable.
If the run is red and mentions 'does not expose bid rows as static HTML',
the state site renders rows dynamically; we need its verified data endpoint.

The workflow and existing federal updater do not need changes.
The existing iowa_sources.json is left alone.
This test is only for the State of Iowa. It does not connect cities/counties yet.
